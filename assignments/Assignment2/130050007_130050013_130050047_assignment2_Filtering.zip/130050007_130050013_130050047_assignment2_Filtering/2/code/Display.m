%% Function - Display
% Function to display any image with desired colourmap and axis

function [] = Display(input_Matrix)

imshow(input_Matrix,[])
colorbar
axis on

end

