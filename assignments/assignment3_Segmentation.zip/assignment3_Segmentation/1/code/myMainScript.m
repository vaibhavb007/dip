%% MyMainScript

tic;
%% Your code here

toc;
